DiSoal no 1 : Saya buat datajson seperti kriteria soal lalu saya ubah

Soal 2 : validasinya menggunakan pattern

soal 3: Generate codenya pake JS bisa dicustom brp mau keluar SNnya dan brp panjangnya

soal 4: kembalian simple stlh diklik tombol maka akan keluar brp kembaliannya

soal 5 : membuat teks sprti itu menggunakan table , tr,td

soal 6 : SQL inner join biasa

soal 7 : soal 5 dan soal 6 digabungkan menjadi 1 file untuk soal 5 saya hanya include 'soal5.php' saja


NB : jika readme.mdnya salah mohon maaf karna tidak pernah buat seperti ini sebelumnya 

asset : bootstrap4